ALTER TABLE users
ADD tokenpassword varchar(64) DEFAULT null;