alter table sharedlists
drop iduserlist