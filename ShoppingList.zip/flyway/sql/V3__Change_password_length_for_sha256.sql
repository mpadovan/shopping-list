ALTER TABLE users
MODIFY COLUMN password varchar(43);
