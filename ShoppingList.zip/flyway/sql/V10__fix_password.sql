alter table users
modify password varchar(64) not null